package com.springboot.sample.project.SpringBootSampleProj.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="All details about the Entity Station")
@Entity
public class Station {
	
	@Size(min=2, message="StationID should have atleast 5 characters")
	@ApiModelProperty(notes="StationID should have atleast 5 characters")
	@Id
	private String stationId;
	
	@Size(min=2, message="Name should have atleast 2 characters")
	@ApiModelProperty(notes="Name should have atleast 2 characters")
	private String name;
	
	@ApiModelProperty(notes="hdEnabled value is true or false")
	private Boolean hdEnabled;
	
	@Size(min=2, message="callSign should have atleast 2 characters")
	@ApiModelProperty(notes="callSign should have atleast 2 characters")
	private String callSign;
	
	public Station() {
		super();
	}
	
	public Station(String stationId, String name, Boolean hdEnabled, String callSign) {
		super();
		this.stationId=stationId;
		this.name = name;
		this.hdEnabled = hdEnabled;
		this.callSign = callSign;
	}
	public String getStationId() {
		return stationId;
	}
	public void setStationId(String stationId) {
		this.stationId = stationId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Boolean getHdEnabled() {
		return hdEnabled;
	}
	public void setHdEnabled(Boolean hdEnabled) {
		this.hdEnabled = hdEnabled;
	}
	public String getCallSign() {
		return callSign;
	}
	public void setCallSign(String callSign) {
		this.callSign = callSign;
	}
	@Override
	public String toString() {
		return "Station [stationId=" + stationId + ", name=" + name + ", hdEnabled=" + hdEnabled + ", callSign="
				+ callSign + "]";
	} 
	

}
