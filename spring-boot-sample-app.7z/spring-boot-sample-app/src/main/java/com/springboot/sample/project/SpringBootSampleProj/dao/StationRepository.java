package com.springboot.sample.project.SpringBootSampleProj.dao;


import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.springboot.sample.project.SpringBootSampleProj.bean.Station;


@Mapper
public interface StationRepository {
	@Select("select * from station")
	public List<Station> findAll();

	@Select("SELECT * FROM station WHERE stationid = #{stationid}")
	public Station findById(String stationid);

	@Delete("DELETE FROM station WHERE stationid = #{stationid}")
	public String deleteById(String stationid);

	@Insert("INSERT INTO station(stationid, name, hdenabled, callsign) VALUES (#{stationid}, #{name}, #{hdenabled}, #{callsign})")
	public String insert(Station station);

	@Update("Update station set name=#{name}, hdenabled=#{hdenabled},callsign=#{callsign}  where stationid=#{stationid}")
	public Station update(Station station);

}