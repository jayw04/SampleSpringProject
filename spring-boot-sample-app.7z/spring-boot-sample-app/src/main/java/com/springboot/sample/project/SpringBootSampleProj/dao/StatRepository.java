package com.springboot.sample.project.SpringBootSampleProj.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springboot.sample.project.SpringBootSampleProj.bean.Station;

@Repository
public interface StatRepository extends JpaRepository<Station, Integer>{

}
