package com.springboot.sample.project.SpringBootSampleProj.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.springboot.sample.project.SpringBootSampleProj.bean.Station;

@Component
public class StationRepositoryImpl implements StationRepository {
	
	public List<Station> findAll()
	{ return findAll();
	
	};

	
	public Station findById(String stationid)
	{
		return findById(stationid);
	};


	public String deleteById(String stationid)
	{
		return deleteById(stationid);
	}

	
	public String insert(Station station)
	{
		insert(station);
		return station.getStationId();
	}
	
	public Station update(Station station) {
          return update(station);
	}
}
