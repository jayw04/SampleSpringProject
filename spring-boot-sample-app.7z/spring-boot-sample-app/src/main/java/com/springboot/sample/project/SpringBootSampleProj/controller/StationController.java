package com.springboot.sample.project.SpringBootSampleProj.controller;

import java.net.URI;
import java.util.List;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.springboot.sample.project.SpringBootSampleProj.bean.Station;
import com.springboot.sample.project.SpringBootSampleProj.dao.RecordNotFoundException;
import com.springboot.sample.project.SpringBootSampleProj.dao.StatRepository;

@RestController
public class StationController {
	@Autowired
	private StatRepository repository;
	
	@PostMapping("/add")
	public ResponseEntity<Object> createStudent(@RequestBody Station station) {
		station.setStationId(UUID.randomUUID().toString());
		station.getHdEnabled();
		Station savedStation = repository.save(station); 

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{stationid}").buildAndExpand(savedStation.getStationId())
				.toUri();

		return ResponseEntity.created(location).build();
		
	}
	
	@PostMapping(value="/update")
	public String updateStation(@Valid @RequestBody Station station) {
	   repository.save(station);   
	   return("station");
	}
	
	@DeleteMapping(value="/delete")
	public void deleteStation(@Valid @RequestBody Station station) 
	
	{
	    repository.delete(station);	
	}
	
	@GetMapping(value="/all")
		public List<Station> findAllStation() 
	{  
	   List<Station> stations =repository.findAll();   
	   
		if(stations==null)
			throw new RecordNotFoundException("No Record in the table");		
	   return stations;
	}
	
	@GetMapping(value="/")
	public String Station() 
	{  
		return "station";
	}


}
