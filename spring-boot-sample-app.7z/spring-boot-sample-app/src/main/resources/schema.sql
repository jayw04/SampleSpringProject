create table station
(
   stationid varchar(50) not null,
   name varchar(255) not null,
   hdenabled BOOLEAN not null,
   callsign varchar(255) not null,
   primary key(stationid)
);